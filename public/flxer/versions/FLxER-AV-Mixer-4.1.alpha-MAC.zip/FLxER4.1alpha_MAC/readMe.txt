///////////////////////////////////////////
/                                         /
/ XXXXX X     X   X xxxxx xxxx            /
/ X     X      X X  x     x   x           /
/ XXX   X       X   xxx   xxxx            /
/ X     X      X X  x     x  x            /
/ X     XXXXX X   X xxxxx x   x   4alpha  /
/                                         /
///////////////////////////////////////////

>> BEFORE START ___________________________

FLxER is a free software made with internet tecnology so for security reasons doesn't read the content of your hard disk. every video file and plug-in, wipe, effect, has to be addeed to the xml files that the application loads before to start.

>> SUGESTIONS _____________________________

1) Launch the application FLxER (MAC) / FLXER.exe (PC) / FLxER.htm (LINUX) and take a tour of the funcnionality start from "select library" and load some movie.


2) If you enjoy flxer and you want to try playing with your movies and files you have to modify the configuration files.

2.a) First step: open the files "library/default.xml" with txt editor and follow comments to add your file.

2.b) Duplicate the file "library/default.xml" to create more compilation files 

2.c) Open the file "preferences/flxer_pref.xml" to add the name of your new complilation.

2.c) Follow the comments on "preferences/flxer_pref.xml" to setup flxer settings


UPGRADING FLxER 3.0.1 _____________________

1) Unzip FLxER4 in a new folder

2) overwrite the library folder with your flxer3 library folder

3) open your old "preferences/flxer_pref.flx" and copy all the rows of of librarys files name (inside the node <librarys>)

4) open the new "preferences/flxer_pref.xml" and paste it into the second node (<librarys>)


FLxER 4 FEATURES __________________________

- 7 channels video mixer

- Supported media: .swf (full ActionScrpt 8 support), .flv, .jpg, .gif, .png, .txt

- Advanced live text editor over all channels

- DV-IN Analog and digital over all channels

- HD output resolution starting from 800x600

- Full Colors and Trasform palette

- 14 Blend options over all channels

- Effects and Analog effects as blur over all channels

- Completly customizable list of Wipes

- Video Sequencer  over all channels

- XML VIDEO RECORDER to share or recall your livesets in a few bytes

- XML VIDEO PLAYER

- BROADCAST VIDEO DELIVERY to share in real time your liveset all over the world or to use more pc to do a live set

- BROADCAST VIDEO PLAYER

 